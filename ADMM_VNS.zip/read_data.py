#######################################
#   read_data
#   用途:读取数据集，并对数据集的数据进行预处理，并将最后的结果通过写入文件输出
#   by noir
#######################################
from head_file import *
import head_file
import openpyxl
import random  #


################################
#   read_data
#   用途:读取数据集进行求解
#   by noir
################################
def read_data():
    xlsx_file = openpyxl.load_workbook(read_data_file_name)
    node_sheet = xlsx_file.get_sheet_by_name("node")
    link_sheet = xlsx_file.get_sheet_by_name("link")

    head_file.customer_size = node_sheet.cell(row=2, column=7).value
    head_file.charging_station_size = node_sheet.cell(row=2, column=8).value

    # node
    for i in range(head_file.customer_size + head_file.charging_station_size + 1):
        node.append(Node())
        node[i].node_id = int(node_sheet.cell(row=i + 2, column=1).value)
        node[i].node_type = int(node_sheet.cell(row=i + 2, column=2).value)
        node[i].pack_wight = float(node_sheet.cell(row=i + 2, column=3).value)
        node[i].pack_volume = float(node_sheet.cell(row=i + 2, column=4).value)
        if node[i].node_type == 3 or node[i].node_type == 1:  # 仓库和充电站
            node[i].node_earliest_time = 480 - head_file.depot_earliest_time
            node[i].node_last_time = 1440 - head_file.depot_earliest_time
        else:  # 客户点
            node[i].node_earliest_time = int(node_sheet.cell(row=i + 2, column=5).value) - head_file.depot_earliest_time
            node[i].node_last_time = int(node_sheet.cell(row=i + 2, column=6).value) - head_file.depot_earliest_time

    # link
    i = 0
    while link_sheet.cell(row=i + 2, column=1).value != None:
        link_id = int(link_sheet.cell(row=i + 2, column=1).value)
        from_node_id = int(link_sheet.cell(row=i + 2, column=2).value)
        to_node_id = int(link_sheet.cell(row=i + 2, column=3).value)
        distance = int(link_sheet.cell(row=i + 2, column=4).value)
        spend_time = int(link_sheet.cell(row=i + 2, column=5).value)
        while from_node_id + 1 > len(link):
            link.append([])
        while to_node_id + 1 > len(link[from_node_id]):
            link[from_node_id].append(Link())

        link[from_node_id][to_node_id].link_id = link_id
        link[from_node_id][to_node_id].from_node_id = from_node_id
        link[from_node_id][to_node_id].to_node_id = to_node_id
        link[from_node_id][to_node_id].distance = distance
        link[from_node_id][to_node_id].spend_time = spend_time

        i += 1

    print("data_read_complete")


###################################
#   ADMM_output()
#   用途：将ADMM运算的结果进行输出
###################################
def ADMM_output():
    wb = openpyxl.Workbook()
    ws_sever_time = wb.create_sheet("sever_time", 0)
    ws_agent_record = wb.create_sheet("agent_record", 1)
    ws_ADMM = wb.create_sheet("ADMM_record", 2)

    ws_sever_time.cell(row=1, column=1).value = "ADMM_num"
    ws_sever_time.cell(row=1, column=2).value = "node_id"
    ws_sever_time.cell(row=1, column=3).value = "sever_time"
    ws_sever_time.cell(row=1, column=4).value = "node_penalty"
    ws_sever_time.cell(row=1, column=5).value = "node_double_penalty"
    ws_sever_time.cell(row=1, column=6).value = "node_double_penalty"

    # 记录每个节点的访问记录
    for i in range(len(head_file.ADMM_iteration_record)):
        for j in range(head_file.customer_size + 1):
            ws_sever_time.cell(row=(i * head_file.customer_size) + j + 2, column=1).value = i
            ws_sever_time.cell(row=(i * head_file.customer_size) + j + 2, column=2).value = j
            ws_sever_time.cell(row=(i * head_file.customer_size) + j + 2, column=3).value = \
                head_file.node_sever_time_record[i][j]
            ws_sever_time.cell(row=(i * head_file.customer_size) + j + 2, column=4).value = \
                    head_file.node_penalty_record[i][j]
            # ws_sever_time.cell(row=(i * head_file.customer_size) + j + 2, column=5).value = \
            #     head_file.node_double_penalty_record[i][j]
            ws_sever_time.cell(row=(i * head_file.customer_size) + j + 2, column=5).value = \
                head_file.node_sever_time_I_record[i][j]

    ws_agent_record.cell(row=1, column=1).value = "ADMM_num"
    ws_agent_record.cell(row=1, column=2).value = "agent_id"
    ws_agent_record.cell(row=1, column=3).value = "agent_record"
    ws_agent_record.cell(row=1, column=4).value = "primal_cost"
    ws_agent_record.cell(row=1, column=5).value = "label_cost"

    # 记录每台车辆的路线记录
    for i in range(len(head_file.ADMM_iteration_record)):
        for j in range(len(head_file.ADMM_iteration_record[i])):
            ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=1).value = i
            ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=2).value = j
            ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=3).value = str(head_file.ADMM_iteration_record[i][j].node_id_record)
            ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=4).value = head_file.ADMM_iteration_record[i][j].label_cost
            ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=5).value = head_file.ADMM_iteration_record[i][j].label_cost_lr
            # ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=6).value = head_file.ADMM_iteration_record[i][j].label_cost_const
            # ws_agent_record.cell(row=(i*head_file.vehicle_fleet_size) + j + 2, column=7).value = head_file.ADMM_iteration_record[i][j].lower_bound


    # 记录ADMM每次的上下界记录(全保留)
    ws_ADMM.cell(row=1, column=1).value = "ADMM_num"
    ws_ADMM.cell(row=1, column=2).value = "label_cost_total"
    ws_ADMM.cell(row=1, column=3).value = "label_cost_const_total"

    label_cost_total_last = 0
    label_cost_total_list = []
    head_file.satisfy_num = 0
    for i in range(len(head_file.ADMM_iteration_record)):
        label_cost_total = 0
        if len(head_file.ADMM_iteration_record[i]) == head_file.vehicle_fleet_size:
            for j in range(head_file.vehicle_fleet_size):
                label_cost_total += head_file.ADMM_iteration_record[i][j].label_cost
            label_cost_total_list.append(label_cost_total)


            head_file.satisfy_num = head_file.node_sever_time_record[i][1:head_file.customer_size + 1].count(1)


            ws_ADMM.cell(row=i+2, column=1).value = i
            ws_ADMM.cell(row=i+2, column=2).value = label_cost_total
            print("ADMM label_cost_total" + str(label_cost_total))
            ws_ADMM.cell(row=i+2, column=3).value = head_file.label_cost_const_total_list[i]
            ws_ADMM.cell(row=i + 2, column=4).value = head_file.satisfy_num

            if i < 10:
                label_cost_total_picture = 0
                for k in range(0,i+1):
                    label_cost_total_picture += label_cost_const_Lower_bound[k]
                if i != 0:
                    ws_ADMM.cell(row=i + 2, column=5).value = label_cost_total_picture/i
                else:
                    ws_ADMM.cell(row=i + 2, column=5).value = label_cost_total_picture
            else:
                label_cost_total_picture = 0
                for k in range(i-9, i+1):
                    label_cost_total_picture += label_cost_const_Lower_bound[k]
                ws_ADMM.cell(row=i + 2, column=5).value = label_cost_total_picture/10
            ws_ADMM.cell(row=i + 2, column=6).value = head_file.label_cost_const_Upper_bound[i]


    wb.save("ADMM_output_data.xlsx")

    print("ADMM_output_complete")


#######################################
#   read_JD_data()
#   用途:读取京东原始数据集的数据
#   by noir
#######################################
def read_JD_data():  # 读取txt文件
    #####################################node####################################
    node_file = open(node_data_file_name)
    node_data = node_file.readlines()
    node_date_len = len(node_data)
    for i in range(node_date_len - 1):
        node.append(Node())
        node_split_data = node_data[i + 1].split("\t")
        node[i].node_id = int(node_split_data[0])
        node[i].node_type = int(node_split_data[1])
        if node[i].node_type == 2:
            node[i].pack_wight = float(node_split_data[2])
            node[i].pack_volume = float(node_split_data[3])
            node_earliest_time_split = node_split_data[4].split(":")  # 时间窗
            node[i].node_earliest_time = int(node_earliest_time_split[0]) * 60 + int(node_earliest_time_split[1])
            node_last_time_split = node_split_data[5].split(":")
            node[i].node_last_time = int(node_last_time_split[0]) * 60 + int(node_last_time_split[1].split("\n")[0])
        elif node[i].node_type == 3 and head_file.customer_size == 0:  # 记录客户数量
            head_file.customer_size = node[i].node_id - 1
        elif node[i].node_type == 4 and head_file.charging_station_size == 0:  # 记录充电站数量
            head_file.charging_station_size = node[i].node_id - head_file.customer_size - 1
    head_file.node_size = head_file.customer_size + head_file.charging_station_size + 1  # 1代表起始仓库

    #####################################link##################################
    #   link[from_node_id][to_node_id](link索引说明)
    link_file = open(link_data_file_name)
    link_data = link_file.readlines()
    link_date_len = len(link_data)
    link_len = 0
    link.append([])
    for i in range(link_date_len - 1):
        link_data_split = link_data[i + 1].split(",")
        if int(link_data_split[1]) != link_len:
            link_len = len(link)
            link.append([])

        z = len(link[link_len])
        link[link_len].append(Link())
        if link_len == z:
            z = len(link[link_len])
            link[link_len].append(Link())
        link[link_len][z].link_id = int(link_data_split[0])
        link[link_len][z].from_node_id = int(link_data_split[1])
        link[link_len][z].to_node_id = int(link_data_split[2])
        link[link_len][z].distance = int(link_data_split[3])
        link[link_len][z].spend_time = int(link_data_split[4].split("\n")[0])

#######################################
#   read_JD_data()
#   用途:读取京东原始数据集的数据
#   by noir
#######################################



################################################
#   output_data_set(customer_num,charging_station_num)
#   input:customer_num(生成数据库客户点数量),charging_station_num(生成数据)
#   用途:从原数据集中摘用一部分做新的数据集(随机原则)
#   by noir
################################################
def output_data_set(customer_num, charging_station_num):
    wb = openpyxl.Workbook()
    ws_node = wb.create_sheet("node", 0)
    ws_link = wb.create_sheet("link", 1)

    #########################node##############################
    # 标签
    ws_node.cell(row=1, column=1).value = "ID"
    ws_node.cell(row=1, column=2).value = "type"
    ws_node.cell(row=1, column=3).value = "pack_total_weight"
    ws_node.cell(row=1, column=4).value = "pack_total_volume"
    ws_node.cell(row=1, column=5).value = "first_receive_tm"
    ws_node.cell(row=1, column=6).value = "last_receive_tm"

    ws_node.cell(row=1, column=7).value = "customer_size"
    ws_node.cell(row=1, column=8).value = "charging_size"
    ws_node.cell(row=2, column=7).value = customer_num
    ws_node.cell(row=2, column=8).value = charging_station_num

    # 仓库
    ws_node.cell(row=2, column=1).value = 0
    ws_node.cell(row=2, column=2).value = node[0].node_type
    ws_node.cell(row=2, column=3).value = node[0].pack_wight
    ws_node.cell(row=2, column=4).value = node[0].pack_volume
    ws_node.cell(row=2, column=5).value = node[0].node_earliest_time
    ws_node.cell(row=2, column=6).value = node[0].node_last_time

    # 客户
    ban_list = [0]  # 防止随机出相同的节点
    k = 0
    for i in range(customer_num):
        while ban_list.count(k) != 0:
            k = random.randint(1, head_file.customer_size)
        ban_list.append(k)

        ws_node.cell(row=i + 3, column=1).value = i + 1
        ws_node.cell(row=i + 3, column=2).value = node[k].node_type
        ws_node.cell(row=i + 3, column=3).value = node[k].pack_wight
        ws_node.cell(row=i + 3, column=4).value = node[k].pack_volume
        ws_node.cell(row=i + 3, column=5).value = node[k].node_earliest_time
        ws_node.cell(row=i + 3, column=6).value = node[k].node_last_time

    # 充电站
    for i in range(charging_station_num):
        while ban_list.count(k) != 0:
            k = random.randint(head_file.customer_size, head_file.customer_size + head_file.charging_station_size)
        ban_list.append(k)

        ws_node.cell(row=customer_num + i + 3, column=1).value = customer_num + i + 1  # customer_num + i +1
        ws_node.cell(row=customer_num + i + 3, column=2).value = node[k].node_type
        ws_node.cell(row=customer_num + i + 3, column=3).value = node[k].pack_wight
        ws_node.cell(row=customer_num + i + 3, column=4).value = node[k].pack_volume
        ws_node.cell(row=customer_num + i + 3, column=5).value = node[k].node_earliest_time
        ws_node.cell(row=customer_num + i + 3, column=6).value = node[k].node_last_time

    ###########################link##################################
    # 标签
    ws_link.cell(row=1, column=1).value = "ID"
    ws_link.cell(row=1, column=2).value = "from_node"
    ws_link.cell(row=1, column=3).value = "to_node"
    ws_link.cell(row=1, column=4).value = "distance"
    ws_link.cell(row=1, column=5).value = "spend_tm"

    # 仓库
    ban_list_len = len(ban_list)
    row_num = 1
    for i in range(ban_list_len):
        for j in range(ban_list_len):
            if i == j:
                continue
            row_num += 1
            ws_link.cell(row=row_num, column=1).value = row_num - 2
            ws_link.cell(row=row_num, column=2).value = i
            ws_link.cell(row=row_num, column=3).value = j
            ws_link.cell(row=row_num, column=4).value = link[ban_list[i]][ban_list[j]].distance
            ws_link.cell(row=row_num, column=5).value = link[ban_list[i]][ban_list[j]].spend_time

    wb_name = "noir_data_set" + str(customer_num) + "_" + str(charging_station_num) + ".xlsx"
    wb.save(wb_name)
