import head_file
from head_file import *
import copy
import random


#####################################################
#   ADMM_VNS_between_vehicle(ADMM_solve)
#   用途：对于路径间进行搜索
#   input：ADMM_solve(ADMM的当代解)
#   by noir(可能会导致漏点)
#######################################################
def ADMM_VNS_between_route(ADMM_solve):
    # 将代价大的路线的节点一个一个弹出然后插入到最小代价的路线
    ADMM_VNS_solve = copy.deepcopy(ADMM_solve)
    ADMM_VNS_solve_len = len(ADMM_VNS_solve)
    # ADMM_VNS_solve.sort(key=lambda x: x.label_cost)
    ADMM_VNS_solve_label_cost_B = None
    ADMM_VNS_solve_label_cost_S = None

    # print(ADMM_VNS_solve[0].label_cost)
    # print(ADMM_VNS_solve[ADMM_VNS_solve_len - 1].label_cost)
    # for i in range(len(ADMM_VNS_solve)):
    #     print(ADMM_VNS_solve[i].node_id_record)

    VNS_BR_end_flag = 0
    same_flag = 0
    VNS_num = 0 # VNS迭代次数防止迭代过度
    VNS_infinite = 0
    if head_file.node_sever_time[1:head_file.customer_size + 1].count(1) == head_file.customer_size:
        VNS_infinite = 1

    while VNS_BR_end_flag != 1:
        if VNS_num > 100 and VNS_infinite == 0:
            break
        VNS_num += 1

        ADMM_VNS_solve.sort(key=lambda x: x.label_cost)
        ADMM_VNS_cost = ADMM_VNS_solve[0].label_cost + ADMM_VNS_solve[ADMM_VNS_solve_len - 1].label_cost

        # print(ADMM_VNS_solve[ADMM_VNS_solve_len-1].node_id_record)

        find_better_flag = 0
        # ADMM_VNS_solve_last_B = copy.deepcopy(ADMM_VNS_solve[ADMM_VNS_solve_len - 1])
        # ADMM_VNS_solve_last_S = copy.deepcopy(ADMM_VNS_solve[0])
        for i in range(len(ADMM_VNS_solve[ADMM_VNS_solve_len - 1].node_id_record) - 1):
            same_flag = 0
            if len(ADMM_VNS_solve[ADMM_VNS_solve_len - 1].node_id_record) == 2:
                VNS_BR_end_flag = 1
                break
            if find_better_flag == 1:
                break
            ADMM_VNS_solve_last_B = copy.deepcopy(ADMM_VNS_solve[ADMM_VNS_solve_len - 1])
            pop_element = ADMM_VNS_solve_last_B.node_id_record.pop(i)
            ADMM_VNS_solve_label_cost_B = calculate_cost(ADMM_VNS_solve_last_B.node_id_record)
            if ADMM_VNS_solve_label_cost_B is None:
                continue
            # print(ADMM_VNS_solve_label_cost_B)
            # print("ADMM_VNS_solve_len-1" + str(ADMM_VNS_solve[ADMM_VNS_solve_len-1].node_id_record))

            for j in range(len(ADMM_VNS_solve[0].node_id_record) - 1):
                ADMM_VNS_solve_last_S = copy.deepcopy(ADMM_VNS_solve[0])
                if ADMM_VNS_solve_last_S.node_id_record.count(pop_element) != 0:
                    same_flag = 1
                    if i == len(ADMM_VNS_solve[ADMM_VNS_solve_len - 1].node_id_record) - 2 and find_better_flag == 0 and j == len(
                            ADMM_VNS_solve[0].node_id_record) - 2:
                        VNS_BR_end_flag = 1
                    continue
                ADMM_VNS_solve_last_S.node_id_record.insert(j, pop_element)
                ADMM_VNS_solve_label_cost_S = calculate_cost(ADMM_VNS_solve_last_S.node_id_record)
                # print("0" + str(ADMM_VNS_solve[0].node_id_record))
                if ADMM_VNS_solve_label_cost_S is None:
                    if i == len(ADMM_VNS_solve[ADMM_VNS_solve_len - 1].node_id_record) - 2 and find_better_flag == 0 and j == len(
                            ADMM_VNS_solve[0].node_id_record) - 2:
                        VNS_BR_end_flag = 1
                    continue

                # print("ADMM_VNS_solve[B]befor VNS" + str(ADMM_VNS_solve_last_B.node_id_record))
                # print("ADMM_VNS_solve[S]befor VNS" + str(ADMM_VNS_solve_last_S.node_id_record))

                # print("ADMM_VNS_solve_label_cost_B" + str(ADMM_VNS_solve_label_cost_B))
                # print("ADMM_VNS_solve_label_cost_S" + str(ADMM_VNS_solve_label_cost_S))
                if ADMM_VNS_cost > ADMM_VNS_solve_label_cost_B + ADMM_VNS_solve_label_cost_S:
                    ADMM_VNS_cost = ADMM_VNS_solve_label_cost_B + ADMM_VNS_solve_label_cost_S
                    ADMM_VNS_solve[0].label_cost = ADMM_VNS_solve_label_cost_S
                    ADMM_VNS_solve[ADMM_VNS_solve_len - 1].label_cost = ADMM_VNS_solve_label_cost_B
                    ADMM_VNS_solve[0] = copy.deepcopy(ADMM_VNS_solve_last_S)
                    ADMM_VNS_solve[ADMM_VNS_solve_len - 1] = copy.deepcopy(ADMM_VNS_solve_last_B)
                    find_better_flag = 1
                    break

        if find_better_flag == 0 and ADMM_VNS_solve_label_cost_B != None and ADMM_VNS_solve_label_cost_S != None:
            # ADMM_VNS_solve[ADMM_VNS_solve_len - 1] = copy.deepcopy(ADMM_VNS_solve_last_B)
            # ADMM_VNS_solve[0] = copy.deepcopy(ADMM_VNS_solve_last_S)
            VNS_BR_end_flag = 1


    for i in range(len(ADMM_VNS_solve)):
        # print("ADMM_VNS_route before route" + str(ADMM_VNS_solve[i].node_id_record))

        ADMM_VNS_solve[i] = ADMM_VNS_route(ADMM_VNS_solve[i])

        # print("ADMM_VNS_solve[" + str(i) + "]" + str(ADMM_VNS_solve[i].node_id_record))

    ADMM_VNS_solve.sort(key=lambda x: x.label_cost)
    return ADMM_VNS_solve


######################################################
#   ADMM_VNS_route(ADMM_solve)
#   用途：对于路径上的路径进行搜索
#   input：ADMM_solve(ADMM的路径解)
#   by noir 出现将元素弹出不见的问题
######################################################
def ADMM_VNS_route(ADMM_route_solve):
    VNS_route = copy.deepcopy(ADMM_route_solve.node_id_record)
    VNS_route_len = copy.deepcopy(len(VNS_route))
    VNS_route_cost = copy.deepcopy(ADMM_route_solve.label_cost)

    if len(VNS_route) == 2:
        return ADMM_route_solve
    VNS_end_flag = 0
    # 对条路径进行局部搜索(插入)
    while VNS_end_flag == 0:
        for i in range(VNS_route_len - 1):
            VNS_temp_route = copy.deepcopy(VNS_route)

            VNS_element = VNS_temp_route.pop(i)
            # print("VNS_element" + str(VNS_element))

            for j in range(VNS_route_len - 1):
                # print("j" + str(j))
                VNS_temp_route.insert(j, VNS_element)
                # print(VNS_temp_route)
                VNS_temp_route_cost = copy.deepcopy(calculate_cost(VNS_temp_route))

                if VNS_temp_route_cost is None:
                    VNS_temp_route.pop(j)
                    # 如果找不到更好的插入，将元素补回
                    if j == VNS_route_len - 2:
                        VNS_temp_route.insert(i, VNS_element)

                    if i == VNS_route_len - 2 and j == VNS_route_len - 2:
                        VNS_end_flag = 1
                    continue
                elif VNS_route_cost > VNS_temp_route_cost:
                    VNS_route_cost = VNS_temp_route_cost
                    VNS_route = copy.deepcopy(VNS_temp_route)
                    # print("VNS_route = " + str(VNS_route))
                    # print("VNS_route_cost = " + str(VNS_route_cost))
                    VNS_end_flag = 0
                    break
                # 没有找到更优的局部解
                elif i == VNS_route_len - 2 and j == VNS_route_len - 2:
                    VNS_end_flag = 1
                    VNS_temp_route.pop(j)
                    VNS_temp_route.insert(i, VNS_element)
                    break
                VNS_temp_route.pop(j)
                # print(VNS_temp_route)

    ADMM_route_solve.node_id_record = VNS_route
    ADMM_route_solve.label_cost = VNS_route_cost

    return ADMM_route_solve


##################################################################################
#   calculate_cost(route)
#   用途：用于计算局部搜索后的路径成本
#  by noir
##################################################################################
def calculate_cost(route):
    # 路径长度
    route_len = len(route)

    # 载重约束和体积约束
    route_weight = 0
    route_volume = 0
    for i in range(route_len):
        route_weight += head_file.node[route[i]].pack_wight
        route_volume += head_file.node[route[i]].pack_volume
    # 违反体积和载重约束
    if route_volume > head_file.vehicle_volume_limit or route_weight > head_file.vehicle_weight_limit:
        # print("违反载重约束")
        return

    # 等待时间(存在时间约束不满足条件的直接跳出)
    route_time = 0
    route_wait_time = 0
    # 从起始仓库出发
    if head_file.link[0][route[0]].spend_time < head_file.node[route[0]].node_earliest_time:
        route_time += head_file.node[route[0]].node_earliest_time + 30
        route_wait_time += head_file.node[route[0]].node_earliest_time - head_file.link[0][route[0]].spend_time
    else:
        route_time += head_file.link[0][route[0]].spend_time + 30
    # 后面节点的等待时间计算
    for i in range(route_len - 1):
        # 违反时间窗约束结束计算
        if route_time + head_file.link[route[i]][route[i + 1]].spend_time > head_file.node[route[i + 1]].node_last_time:
            # print("route" + str(route))
            # print("from_node_id" + str(route[i]))
            # print("to_node_id" + str(route[i+1]))
            # print("route_time + head_file.link[route[i]][route[i+1]].spend_time" + str(route_time + head_file.link[route[i]][route[i+1]].spend_time))
            # print("head_file.node[route[i+1]].node_last_time" + str(head_file.node[route[i+1]].node_last_time))
            # print("违反时间窗约束")
            return
        if route_time + head_file.link[route[i]][route[i + 1]].spend_time < head_file.node[route[i]].node_earliest_time:
            route_wait_time += head_file.node[route[i]].node_earliest_time - (
                        route_time + head_file.link[route[i]][route[i + 1]].spend_time)
            route_time += head_file.node[route[i]].node_earliest_time + 30
        else:
            route_time += head_file.link[route[i]][route[i + 1]].spend_time + 30

    # 距离
    route_distance = head_file.link[0][route[0]].distance
    distance_remain = head_file.vehicle_distance_limit
    route_charge = 0
    for i in range(route_len - 1):
        route_distance += head_file.link[route[i]][route[i + 1]].distance
        # 访问了充电站
        if head_file.customer_size < route[i]:
            distance_remain = head_file.vehicle_distance_limit
            route_charge += 1
        else:
            distance_remain -= head_file.link[route[i]][route[i + 1]].distance
        if distance_remain < 0:

            # print("违反续航约束")
            return

    # 成本计算
    route_cost = 0
    route_cost += route_distance / 1000 * 12
    route_cost += route_wait_time * 0.4
    route_cost += route_charge * 50

    # print("route_cost = " + str(route_cost))
    return route_cost

###################################################
#
#   用途：通过启发式算法形成一个算法上界
#   by noir
###################################################
def calculate_upper_bound(ADMM_input):
    feasible_flag = 1
    Upperbound_node_id_record = []
    Upperbound_return = 0
    for i in range(len(ADMM_input)):
        Upperbound_node_id_record.append([])
        Upperbound_node_id_record[i] = copy.deepcopy(ADMM_input[i].node_id_record)
        # print("Upperbound_node_id_record" + str(i) + str(calculate_cost(Upperbound_node_id_record[i])))

    # 将多访问的点去掉
    for i in range(1, head_file.customer_size + 1):
        # 满足约束跳过
        if head_file.node_sever_time[i] == 1:
            continue
        # 如果车辆
        if head_file.node_sever_time[i] != 0:
            for j in range(head_file.node_sever_time[i] - 1):  # 将多访问的次数全部去掉
                for k in range(len(Upperbound_node_id_record)):
                    if Upperbound_node_id_record[k].count(i) == 0:
                        continue
                    else:
                        index_i = Upperbound_node_id_record[k].index(i)
                        Upperbound_node_id_record[k].pop(Upperbound_node_id_record[k].index(i))
                        if calculate_cost(Upperbound_node_id_record[k]) != None:
                            break
                        else:
                            Upperbound_node_id_record[k].insert(index_i, i)

    # 将未访问的点加入
    for i in range(1, head_file.customer_size +1):
        Upperbound_flag=0
        if head_file.node_sever_time[i] >= 1:
            continue
        if head_file.node_sever_time[i] == 0:
            for j in range(len(Upperbound_node_id_record)):
                for k in range(len(Upperbound_node_id_record[j])):
                    Upperbound_node_id_record[j].insert(k, i)
                    if calculate_cost(Upperbound_node_id_record[j]) != None:
                        Upperbound_flag=1
                        break
                    else:
                        Upperbound_node_id_record[j].pop(Upperbound_node_id_record[j].index(i))
                        continue
                if Upperbound_flag==1:
                    break
            if Upperbound_flag == 0:# 无法插入任何车辆
                feasible_flag = 0
                Upperbound_return += 1000

    for i in range(len(Upperbound_node_id_record)):
        # print(Upperbound_node_id_record[i])
        # print("calculate_cost" + str(calculate_cost(Upperbound_node_id_record[i])))
        Upperbound_return += calculate_cost(Upperbound_node_id_record[i])

    # print("Upperbound_return" + str(Upperbound_return))

    return Upperbound_return, feasible_flag