import copy
import head_file
from head_file import *
from dp import *
import time
from heuristic import *
import heuristic
import numpy as np

#######################################
#   ADMM_iteration()
#   用途:通过ADMM求问题模型的解
#   by noir
######################################
def ADMM_iteration():
    # k = []
    # 初始化罚函数系数
    for i in range(head_file.customer_size + head_file.charging_station_size + 1):
        head_file.node_penalty.append(0)
        head_file.node_double_penalty.append(1)
        head_file.node_sever_time_last.append(0)
        head_file.node_sever_time.append(0)
        head_file.node_sever_time_I.append(0)

    time1 = time.time()

    # ADMM迭代
    ADMM_iteration_num = 0
    ADMM_Ending_flag = 0
    # for ADMM_iteration_num in range(head_file.ADMM_iteration_size):

    while ADMM_iteration_num <= head_file.ADMM_iteration_size and ADMM_Ending_flag == 0:
        print("ADMM_iteration_num" + str(ADMM_iteration_num))
        print("time1-time.time()" + str(time.time()-time1))
        if ADMM_Ending_flag == 1 or time.time() - time1 > 3600:
            break

        # 记录每次ADMM迭代完后的数据(跑时间的时候需要屏蔽)
        ########################################################################################

        head_file.node_sever_time_record.append([])  # 记录每次ADMM迭代每个节点给服务的次数
        head_file.ADMM_iteration_record.append([])  # 记录每次ADMM迭代后的解
        head_file.node_double_penalty_record.append([])  # 记录每次ADMM迭代后罚函数系数
        head_file.node_penalty_record.append([])  # 记录每次ADMM迭代后二次罚函数系数
        head_file.node_sever_time_I_record.append([])   # 记录每次迭代后sever_time的积分

        head_file.label_cost_const_Lower_bound.append(0)
        head_file.label_cost_const_Upper_bound.append(9999999999999)
        head_file.label_cost_const_total_list.append(0)
        ########################################################################################

        # 对每辆车进行动态规划
        for v in range(head_file.vehicle_fleet_size):
            if head_file.node_sever_time[1:head_file.customer_size+1].count(1) == head_file.customer_size:
                ADMM_Ending_flag = 1
                break

            if ADMM_iteration_num != 0:
                for i in range(1,head_file.customer_size+1):
                    if head_file.ADMM_iteration_record[ADMM_iteration_num-1][v].node_id_record.count(i) != 0:
                        head_file.node_sever_time[i] -= 1
                # print("动态规划前")
                # print(head_file.node_sever_time)
                head_file.satisfy_num = head_file.node_sever_time[1:head_file.customer_size + 1].count(1)

            head_file.ADMM_iteration_record[ADMM_iteration_num].append(CVSState())

            head_file.ADMM_iteration_record[ADMM_iteration_num][v] = copy.deepcopy(dynamic_programming())

            head_file.node_sever_time_last = copy.deepcopy(head_file.node_sever_time)
            head_file.satisfy_num_last = head_file.node_sever_time[1:head_file.customer_size + 1].count(1)

            # print("head_file.ADMM_iteration_record[ADMM_iteration_num][v]" + str(head_file.ADMM_iteration_record[ADMM_iteration_num][v].node_id_record))

            for i in range(1, head_file.customer_size + 1):
                head_file.node_sever_time[i] += head_file.ADMM_iteration_record[ADMM_iteration_num][v].node_id_record.count(i)
            # print("动态规划后")
            # print(head_file.node_sever_time)

            # 罚函数计算
            for i in range(1, head_file.customer_size + 1):

                # # print("node_sever_time_I" + str(head_file.node_sever_time_I[i]))
                # if (head_file.node_sever_time[i] - 1) ** 2 > 0.25 * (head_file.node_sever_time_last[i] - 1) ** 2:
                #     head_file.node_double_penalty[i] += 3 * abs(head_file.node_sever_time[i] - 1)  # 二次项系数步进距离
                head_file.node_double_penalty[i] += 3

                head_file.node_penalty[i] += (head_file.node_sever_time[i] - 1) * head_file.node_double_penalty[i]
        #
        # 局部搜索
        if len(ADMM_iteration_record[ADMM_iteration_num]) != 0:# ADMM_Ending_flag == 0 and
            # 如果ADMM不够补位
            if len(ADMM_iteration_record[ADMM_iteration_num]) <= head_file.vehicle_fleet_size:
                for i in range(head_file.vehicle_fleet_size-len(ADMM_iteration_record[ADMM_iteration_num])):
                    ADMM_iteration_record[ADMM_iteration_num].append(copy.deepcopy(ADMM_iteration_record[ADMM_iteration_num-1][-(i+1)]))

            # 将当代的ADMM结果输入VNS中进行领域搜索(基于TS进行筛选)（每次ADMM结束执行一次）
            # print("ADMM_iteration_record[ADMM_iteration_num]_len" + str(len(ADMM_iteration_record[ADMM_iteration_num])))
            ADMM_iteration_record[ADMM_iteration_num] = ADMM_VNS_between_route(ADMM_iteration_record[ADMM_iteration_num])
            for i in range(len(head_file.ADMM_iteration_record[ADMM_iteration_num])):
                head_file.ADMM_iteration_record[ADMM_iteration_num][i] = \
                    ADMM_VNS_route(head_file.ADMM_iteration_record[ADMM_iteration_num][i])


        # 记录线条(跑时间的时需要屏蔽)
        #######################################################################################################
            # print("node_sever_time" + str(head_file.node_sever_time))
            # print("node_penalty" + str(head_file.node_penalty))
            # print("node_double_penalty" + str(head_file.node_double_penalty))

        # 计算上界
        head_file.label_cost_const_Upper_bound[ADMM_iteration_num], fesable_flag = calculate_upper_bound(
            head_file.ADMM_iteration_record[ADMM_iteration_num])

        if ADMM_Ending_flag == 0:
            label_cost_const_total = 0
            for i in range(head_file.vehicle_fleet_size):
                label_cost_const_total += head_file.ADMM_iteration_record[ADMM_iteration_num][i].label_cost

            head_file.label_cost_const_total_list[ADMM_iteration_num] = label_cost_const_total

            # # 上界只接受更好的结果
            # if label_cost_const_Upper_bound < head_file.label_cost_const_Upper_bound[ADMM_iteration_num-1]:
            #     head_file.label_cost_const_Upper_bound[ADMM_iteration_num] = label_cost_const_Upper_bound
            # else:
            #     head_file.label_cost_const_Upper_bound[ADMM_iteration_num] = copy.deepcopy(head_file.label_cost_const_Upper_bound[ADMM_iteration_num-1])

            # 下界需要根据解的满足数进行分析
            if head_file.satisfy_num < head_file.node_sever_time[1:head_file.customer_size + 1].count(1):
                head_file.satisfy_num = head_file.node_sever_time[1:head_file.customer_size + 1].count(1)
                head_file.label_cost_const_Lower_bound[ADMM_iteration_num] = label_cost_const_total
            else:
                head_file.label_cost_const_Lower_bound[ADMM_iteration_num] = copy.deepcopy(head_file.label_cost_const_Lower_bound[ADMM_iteration_num-1])
            # print("satisfy_num_last" + str(head_file.node_sever_time[1:head_file.customer_size + 1].count(1)))
        ######################################################################################################


        # record
        ######################################################################################################
        head_file.node_sever_time_record[ADMM_iteration_num] = copy.deepcopy(head_file.node_sever_time)
        head_file.node_penalty_record[ADMM_iteration_num] = copy.deepcopy(head_file.node_penalty)
        head_file.node_double_penalty_record[ADMM_iteration_num] = copy.deepcopy(head_file.node_double_penalty)
        head_file.node_sever_time_I_record[ADMM_iteration_num] = copy.deepcopy(head_file.node_sever_time_I)
        ####################################################################################################

        ADMM_iteration_num += 1

    # print(head_file.node_sever_time)
    # print(head_file.node_sever_time[1:head_file.customer_size + 1].count(1))
    time2 = time.time()

    print("ADMM label_cost_total" + str(head_file.label_cost_const_total_list[ADMM_iteration_num-1]))
    print("ADMM_run_time:" + str(time2 - time1))
    print("ADMM_num" + str(ADMM_iteration_num))

    # 记录数据






