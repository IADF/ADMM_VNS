from gurobipy import *
from read_data import *
import head_file
from ADMM import *
from dp import *
from heuristic import *


if __name__ == '__main__':

    # 读取数据
    read_data()

    # 通过ADMM进行求解
    ADMM_iteration()  #

    # 将ADMM结果数据读出
    ADMM_output()
