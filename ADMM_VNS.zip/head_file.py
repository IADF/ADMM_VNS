#################################################
#   头文件
#   用途:用于存放程序中类和常量和变量
#   by noir
################################################

###########################常量#######################################
link_data_file_name = "JD_data\inputdistancetime_0_1101.txt"  # 数据集名称
node_data_file_name = "JD_data\inputnode_0_1101.txt"
read_data_file_name = "./noir_data_set10_4.xlsx"

##########################################
node = []   # 节点
link = []   # 连接
vehicle_route = []    # 车辆路线

##########################变量############################
customer_size = 0   # 客户数量·
charging_station_size = 0  # 充电站数量
vehicle_fleet_size = 4    # 车辆数
vehicle_distance_limit = 200000  # 车辆运输距离限制
vehicle_volume_limit = 12#12   # 车辆容积限制
vehicle_weight_limit = 2#2    # 车辆载重限制

#####################ADMM#####################################
ADMM_iteration_size = 100   # ADMM迭代次数
ADMM_flag = 1               # 是否使用ADMM
dp_distance_limit = 60000   # 运输距离过长的两个节点不选取
dp_time_limit = 80          # 运输时间过大的两个节点不选取
K_size = 100                 # 动态规划每次选取最优前K组进行规划
VNS_size = 10               # 领域搜索次数
node_penalty = []           # 一次惩罚项系数
node_double_penalty = []    # 二次惩罚项系数
node_penalty_record = []           # 记录一次惩罚项系数
node_double_penalty_record = []    # 记录二次惩罚项系数
node_sever_time = []         # 节点被访问次数
node_sever_time_last = []    # 上次节点被访问次数
node_sever_time_record = []  # 记录每次ADMM迭代节点别访问次数
ADMM_iteration_record = []   # 记录每次动态规划和ADMM的结果
depot_earliest_time = 480    # 仓库最早发车时间


####################################################
node_sever_time_I = []
node_sever_time_I_record = []
label_cost_const_total_list = []
label_cost_const_Lower_bound = []
label_cost_const_Upper_bound = []
satisfy_num = 0
satisfy_num_last = 0
######################################################



##########################类#########################################
class Node:
    def __init__(self):
        self.node_id = 0    # 节点id
        self.node_type = 0  # 节点类型（1仓库  2客户 3充电站）
        self.pack_wight = 0.0           # 货物重量
        self.pack_volume = 0.0          # 货物体积
        self.node_earliest_time = 0     # 最早访问的时间窗
        self.node_last_time = 0         # 最晚访问的时间窗


class Link:
    def __init__(self):
        self.link_id = 0    #
        self.from_node_id = 0
        self.to_node_id = 0
        self.distance = 0   # 运输距离
        self.spend_time = 0 # 花费时间


############################
#   动态规划中的使用的对象
############################
class CVSState:
    def __init__(self):
        self.node_id_record = []  # 用来纪录路径的节点顺序
        self.cost_time = 0 # 记录消耗时间
        self.label_cost_record = [0]  # 记录动态规划过程中的代价
        self.label_cost_const = 0
        self.label_cost_record_lr = []  # 记录动态规划加入罚函数的代价
        self.wait_time = [0]     # 记录每个节点的等待时间
        self.label_cost = 0    # 不带任何惩罚的代价函数
        self.batter = vehicle_distance_limit
        self.batter_record = [vehicle_distance_limit]
        self.label_cost_lr = 0
        self.from_node_id = 0
        self.to_node_id = 0
        self.weight = 0.0
        self.volume = 0.0
        self.charging_station_flag = 0
        self.lower_bound = 0


