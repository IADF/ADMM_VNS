import head_file
from head_file import *
import read_data
from read_data import *
import copy
from heuristic import *

###########################################
#   dynamic_programming()
#   用途:通过动态规划求解子问题
#   input:K_size(选取前k个好的个体进行后续规划)(head_file中设置)
#   dynamic_programming_list[0](用于存储动态规划出来的结果)
#   by noir
##########################################
def dynamic_programming():
    # 动态规划列表
    dynamic_programming_list = []
    for i in range(node[0].node_last_time):
        dynamic_programming_list.append([])


    # 动态规划
    for i in range(node[0].node_last_time):
        dp_index = 0
        wait_time = 0
        dynamic_programming_list_i_len = len(dynamic_programming_list[i])

        # 仓库出发
        if i == 0:
            for j in range(len(link[0])):
                # 排出不符合的点
                if 0 >= link[0][j].distance or link[0][j].distance > vehicle_distance_limit:
                    continue
                if node[j].node_type == 2:  # 客户点
                    if link[0][j].spend_time <= node[j].node_earliest_time:  # 早于时间窗到达
                        dp_index = node[j].node_earliest_time + 30
                        wait_time = node[j].node_earliest_time - link[0][j].spend_time
                    else:
                        dp_index = link[0][j].spend_time + 30
                        wait_time = 0
                elif node[j].node_type == 3:  # 充电站
                    continue

                # calculate_cost_list = []
                # calculate_cost_list.append(j)
                # if calculate_cost(calculate_cost_list) == None:
                #     continue

                dp_list_l = len(dynamic_programming_list[dp_index])
                dynamic_programming_list[dp_index].append(CVSState())
                dynamic_programming_list[dp_index][dp_list_l].node_id_record.append(j)
                dynamic_programming_list[dp_index][dp_list_l].from_node_id = 0
                dynamic_programming_list[dp_index][dp_list_l].to_node_id = j
                # 时间窗
                if wait_time == 0:
                    dynamic_programming_list[dp_index][dp_list_l].cost_time = dp_index
                else:
                    dynamic_programming_list[dp_index][dp_list_l].cost_time = dp_index
                # 重量容量
                dynamic_programming_list[dp_index][dp_list_l].weight += node[j].pack_wight
                dynamic_programming_list[dp_index][dp_list_l].volume += node[j].pack_volume
                # 运输距离
                dynamic_programming_list[dp_index][dp_list_l].batter -= link[0][j].distance
                # record_batter
                dynamic_programming_list[dp_index][dp_list_l].batter_record.append(  # 记录每个节点的剩余路程
                    dynamic_programming_list[dp_index][dp_list_l].batter)

                # 代价计算
                # label_cost
                dynamic_programming_list[dp_index][dp_list_l].label_cost += wait_time * 0.4
                dynamic_programming_list[dp_index][dp_list_l].label_cost += link[0][j].distance / 1000 * 12
                dynamic_programming_list[dp_index][dp_list_l].label_cost_lr += \
                    dynamic_programming_list[dp_index][dp_list_l].label_cost

                dynamic_programming_list[dp_index][dp_list_l].label_cost_lr += head_file.node_sever_time[j] * \
                                                                                    head_file.node_penalty[j]
                if head_file.ADMM_flag == 1:
                    dynamic_programming_list[dp_index][dp_list_l].label_cost_lr += (head_file.node_sever_time[
                                j]) ** 2 * head_file.node_double_penalty[j]
                # record
                dynamic_programming_list[dp_index][dp_list_l].label_cost_record.append(
                    dynamic_programming_list[dp_index][dp_list_l].label_cost)
                dynamic_programming_list[dp_index][dp_list_l].label_cost_record_lr.append(
                    dynamic_programming_list[dp_index][dp_list_l].label_cost_lr)
                dynamic_programming_list[dp_index][dp_list_l].wait_time.append(wait_time)

        # 该时间列表为空跳过
        elif dynamic_programming_list_i_len == 0:  
            continue

        # 
        else:
            dynamic_programming_list[i].sort(key=lambda x: x.label_cost_lr)
            if dynamic_programming_list_i_len >= head_file.K_size:
                dynamic_programming_list_i_len = head_file.K_size
            for j in range(dynamic_programming_list_i_len):
                for k in range(len(link[dynamic_programming_list[i][j].to_node_id])):
                    # 电量不允许访问或已经访问过
                    if link[dynamic_programming_list[i][j].to_node_id][k].distance <= 0 or \
                       link[dynamic_programming_list[i][j].to_node_id][k].distance >= dynamic_programming_list[i][j].batter or \
                       dynamic_programming_list[i][j].node_id_record.count(k) != 0:
                        continue

                    calculate_cost_list = copy.deepcopy(dynamic_programming_list[i][j].node_id_record)
                    calculate_cost_list.append(k)
                    if calculate_cost(calculate_cost_list) == None:
                        continue

                    # 不允许重复访问节点
                    if dynamic_programming_list[i][j].node_id_record.count(k) != 0 or\
                        (node[k].node_type == 3 and dynamic_programming_list[i][j].charging_station_flag == 1):
                        continue


                    # 时间窗(超过时间窗约束的约束)(访问过充电站不允许在访问)
                    # if dynamic_programming_list[i][j].to_node_id == 10:
                    #     print("dynamic_programming_list[i][j].cost_time" + str(dynamic_programming_list[i][j].cost_time))
                    #     print("link[dynamic_programming_list[i][j].to_node_id][k].spend_time" + str(link[dynamic_programming_list[i][j].to_node_id][k].spend_time))
                    #     print("node[k].node_last_time" + str(node[k].node_last_time))

                    if dynamic_programming_list[i][j].cost_time + link[dynamic_programming_list[i][j].to_node_id][k].spend_time\
                       > node[k].node_last_time:# dynamic_programming_list[i][j].cost_time
                        continue

                    if node[k].node_type == 3 and dynamic_programming_list[i][j].charging_station_flag == 1:
                        continue
                    
                    # 货物重量和体积超过限制
                    if dynamic_programming_list[i][j].weight + node[k].pack_wight > vehicle_weight_limit or\
                        dynamic_programming_list[i][j].volume + node[k].pack_volume > vehicle_volume_limit:
                        continue

                    # 节点间距离过长的线路直接排除
                    if link[dynamic_programming_list[i][j].to_node_id][k].distance > head_file.dp_distance_limit:
                        continue

                    if k == 0:  # 到达终点

                        dynamic_programming_list0_l = len(dynamic_programming_list[0])  # 记录长度dynamic_programming_list[0]
                        dynamic_programming_list[0].append(head_file.CVSState())
                        dynamic_programming_list[0][dynamic_programming_list0_l] = copy.deepcopy(dynamic_programming_list[i][j])
                        dynamic_programming_list[0][dynamic_programming_list0_l].node_id_record.append(0)   # 添加node
                        dynamic_programming_list[0][dynamic_programming_list0_l].from_node_id = dynamic_programming_list[i][j].to_node_id
                        dynamic_programming_list[0][dynamic_programming_list0_l].to_node_id = 0    # 返回仓库点
                        dynamic_programming_list[0][dynamic_programming_list0_l].cost_time += link[dynamic_programming_list[i][j].to_node_id][k].spend_time # 时间
                        dynamic_programming_list[0][dynamic_programming_list0_l].batter -= link[dynamic_programming_list[i][j].to_node_id][k].distance  # 距离
                        dynamic_programming_list[0][dynamic_programming_list0_l].label_cost += link[dynamic_programming_list[i][j].to_node_id][k].distance / 1000 * 12
                        dynamic_programming_list[0][dynamic_programming_list0_l].label_cost_lr += link[dynamic_programming_list[i][j].to_node_id][k].distance / 1000 * 12

                        # label_cost_record
                        dynamic_programming_list[0][dynamic_programming_list0_l].label_cost_record.append(dynamic_programming_list[0][dynamic_programming_list0_l].label_cost)
                        dynamic_programming_list[0][dynamic_programming_list0_l].label_cost_record_lr.append(dynamic_programming_list[0][dynamic_programming_list0_l].label_cost_lr)
                        # batter_record
                        dynamic_programming_list[0][dynamic_programming_list0_l].batter_record.append(dynamic_programming_list[0][dynamic_programming_list0_l].batter)
                        # wait_record
                        dynamic_programming_list[0][dynamic_programming_list0_l].wait_time.append(0)

                        # 罚函数
                        for l in range(1, head_file.customer_size+1):
                            # 这组规划是否访问l节点
                            if dynamic_programming_list[0][dynamic_programming_list0_l].node_id_record.count(l) == 0:
                                # cost(一次惩罚项)
                                dynamic_programming_list[0][dynamic_programming_list0_l].label_cost_lr += head_file.node_penalty[l] * (head_file.node_sever_time[l] - 1)
                                # cost(二次惩罚项)
                                dynamic_programming_list[0][dynamic_programming_list0_l].label_cost_lr += head_file.node_double_penalty[l] * (head_file.node_sever_time[l] - 1)**2

                    else:   # 到达其他节点
                        if i + link[dynamic_programming_list[i][j].to_node_id][k].spend_time <= node[k].node_earliest_time:
                            dp_index = node[k].node_earliest_time + 30 
                            wait_time = node[k].node_earliest_time - (i + link[dynamic_programming_list[i][j].to_node_id][k].spend_time)  # 等待时间
                        else:
                            dp_index = i + link[dynamic_programming_list[i][j].to_node_id][k].spend_time +30
                            wait_time = 0
                        if dp_index >= node[0].node_last_time:
                            continue

                        dynamic_programming_list_dp_index_len = len(dynamic_programming_list[dp_index])
                        dynamic_programming_list[dp_index].append(head_file.CVSState())
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len] = copy.deepcopy(dynamic_programming_list[i][j])
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].node_id_record.append(k)
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].wait_time.append(wait_time)
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].from_node_id = dynamic_programming_list[i][j].to_node_id
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].to_node_id = k
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].weight += node[k].pack_wight
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].volume += node[k].pack_volume
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].batter -= link[dynamic_programming_list[i][j].to_node_id][k].distance
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].cost_time = dp_index

                        #############################
                        if node[k].node_type == 3:
                            dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].charging_station_flag = 1
                            dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].batter = vehicle_distance_limit
                            # chongdianchengben
                            dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost += 50
                            dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost += 50
                        # cost(距离)
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost += link[dynamic_programming_list[i][j].to_node_id][k].distance / 1000 * 12
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost_lr += link[dynamic_programming_list[i][j].to_node_id][k].distance / 1000 * 12
                        # cost(等待)
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost += wait_time * 0.4
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost_lr += wait_time * 0.4

                        # 罚函数
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost_lr += head_file.node_penalty[k] * head_file.node_sever_time[k]
                        dynamic_programming_list[dp_index][dynamic_programming_list_dp_index_len].label_cost_lr += head_file.node_double_penalty[k] * (head_file.node_sever_time[k])**2

    dynamic_programming_list[0].sort(key=lambda x: x.label_cost_lr)
    return dynamic_programming_list[0][0]




